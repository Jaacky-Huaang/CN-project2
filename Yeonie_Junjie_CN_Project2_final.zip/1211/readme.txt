Hi Dena,

This folder is organized based on your suggested file structure. 

The Makefile is in the main menu, which compiles the ".c" files, stores the ".o" files in the "code" folder, and stores the executable file in the server folder and client folder respectively.

In order to test the code, please type "./server" after entering "server_folder" and type ":/client" after entering the "client_folder".

In the server_folder, the structure is also copied from your suggested structure (with an extra file in bob called "new_image_folder" to test CWD).

Thank you for the semester!

Best,
Junjie and Yeonie